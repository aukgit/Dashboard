﻿; $.app = $.app || {};
; $.app.schema = $.app.schema || {};
;$.app.schema.url = {
    Create: null,
    Edit: null,
    Delete: null,
    Index:null
};