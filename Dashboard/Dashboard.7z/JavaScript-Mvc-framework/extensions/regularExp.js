﻿;$.app.regularExp = {
    friendlyUrl : "[^A-Za-z0-9_\.~]+"
};