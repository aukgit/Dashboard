﻿$.app.selectors = {
    ids : {
        processForm: "server-validation-form",
        bodyStart: "body-start"
    }
};